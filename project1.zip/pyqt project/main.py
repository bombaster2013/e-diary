import sqlite3
import sys
from PyQt5.QtWidgets import QMainWindow, QWidget, QApplication, QMessageBox, QTableWidgetItem, QTableWidget, \
    QPushButton, QFileDialog, QLabel
from PyQt5.QtGui import QPixmap
from registration import Ui_reg_form as UiRf
from selection import Ui_Selection_Form as UiSf
from class_add import Ui_class_add as UiCaf
from pupil_reg import Ui_pupil_reg as UiPrf
from teacher_reg import Ui_teacher_add_form as UiTaf
from class_remove import Ui_class_remove_form as UiCrf
from user_remove import Ui_user_remove_form as UiUrf
from class_change import Ui_class_change as UiCch
from user_change import Ui_user_change as UiUc
from set_rings import Ui_set_rings_form as UiSrf
from add_schedule import Ui_add_schedule_form as UiAsf
from user_main_window import Ui_user_window as UiUw
from teacher_main_window import Ui_teacher_main_window as UiTmw
from homework_add import Ui_add_hw_form as UiHwaf
from mark_add import Ui_mark_add_form as UiMaf
from total_mark_add import Ui_final_mark_add as UiTma
from total_marks_view import Ui_all_marks_view as UiTmv
from test_add import Ui_test_add_form as UiTa
from test_form import Ui_test_form as UiTf
from collections import Counter
import shutil
import csv
import random
import os


def rd(x, y=0):
    """Округление в классическом виде, функция round округляет в сторону ближайшего чётного"""
    m = int('1' + '0' * y)
    q = x * m
    c = int(q)
    i = int((q - c) * 10)
    if i >= 5:
        c += 1
    return c / m


DATABASE_NAME = 'diary_db.sqlite3'


class AddImage:
    def __init__(self, num, form):
        self.num = num
        self.form = form

    def __call__(self):
        self.file, ok_pressed = QFileDialog(self.form).getOpenFileName(self.form, 'Выберите картинку', 'image.png')
        if ok_pressed:
            new_name = self.get_needed_name()
            new_dir = f"images/{new_name}.jpg"
            shutil.copy(self.file, new_dir)
            pixmap = QPixmap(new_dir)
            pixmap = pixmap.scaledToHeight(175)
            label = QLabel(self.form.tableWidget)
            label.setPixmap(pixmap)
            self.form.tableWidget.setCellWidget(1, self.num, label)
            self.form.tableWidget.cellWidget(1, self.num).fileName = new_dir
            self.form.tableWidget.resizeColumnsToContents()
            self.form.tableWidget.resizeRowsToContents()

    def get_needed_name(self):
        return len(os.listdir('images/')) + 1


class Test:
    def __init__(self, prev_form, file_name, user_id, subject_name, date):
        db = sqlite3.connect('diary_db.sqlite3')
        cur = db.cursor()
        self.date = date
        self.cur = 0
        self.questions = list()
        self.prev_form = prev_form
        self.file, self.aoq, self.comment = file_name.split('$')
        self.user_id = user_id
        self.subject_id = cur.execute(f"""
        SELECT id from subjects
        WHERE subject_name = '{subject_name}'
        """).fetchone()[0]
        with open(self.file) as csvfile:
            reader = csv.reader(csvfile, delimiter=';', quotechar='"')
            for index, row in enumerate(reader):
                if index == 0:
                    pass
                else:
                    self.questions.append(row)
        self.questions = self.generate_questions()
        self.corr_answers = [elem[-1] for elem in self.questions]
        self.answers = ['' for _ in range(len(self.questions))]
        self.form = TestForm()
        db.close()
        self.cur_changed()

    def form_init(self):
        self.form.back_button_clicked.connect()
        self.form.fw_button_clicked.connect()
        self.form.save_button_clicked.connect()

    def generate_questions(self):
        return random.sample(self.questions, k=int(self.aoq))

    def __call__(self):
        self.form.show()
        self.prev_form.close()
        self.form.question_label.setWordWrap(True)
        self.form.prev_question_button.clicked.connect(self.back)
        self.form.next_question_button.clicked.connect(self.next)
        self.form.finish_test_button.clicked.connect(self.finish)

    def finish(self):
        self.answers[self.cur] = self.form.answer_line.text()
        corrs = 0
        for i in range(len(self.corr_answers)):
            if self.corr_answers[i].lower() == self.answers[i].lower():
                corrs += 1
        mark = int(rd((corrs / len(self.corr_answers)) * 5))
        db = sqlite3.connect('diary_db.sqlite3')
        cur = db.cursor()
        prev = cur.execute(f"""
        SELECT * FROM marks
        WHERE date = '{self.date}' AND is_test = 1 AND user_id = {self.user_id}
        """).fetchone()
        if prev is None:
            cur.execute(f"""
            INSERT INTO marks (mark, subject_id, user_id, date, is_test)
            VALUES ("{mark}", {self.subject_id}, {self.user_id}, "{self.date}", 1)
            """)
            self.form.box = QMessageBox.information(self.form, 'Тест пройден!', f'Вы прошли тест на {corrs} из '
                    f'{len(self.corr_answers)} \nВаша оценка: {mark}' +
                    (f"комментарий к тесту: {self.comment}" if self.comment else ''), QMessageBox.Ok)
        else:
            self.form.box = QMessageBox.critical(self.form, 'Ошибка!', 'Вы уже проходили этот тест', QMessageBox.Ok)
        db.commit()
        db.close()

    def next(self):
        self.answers[self.cur] = self.form.answer_line.text()
        self.form.next_question_button.setEnabled(True)
        self.form.prev_question_button.setEnabled(True)
        self.cur += 1
        if self.cur == len(self.questions) - 1:
            self.form.next_question_button.setDisabled(True)
        self.form.answer_line.setText(self.answers[self.cur])
        self.cur_changed()

    def back(self):
        self.answers[self.cur] = self.form.answer_line.text()
        self.form.prev_question_button.setEnabled(True)
        self.form.next_question_button.setEnabled(True)
        self.cur -= 1
        if self.cur == 0:
            self.form.prev_question_button.setDisabled(True)
        self.form.answer_line.setText(self.answers[self.cur])
        self.cur_changed()

    def cur_changed(self):
        cur_question = self.questions[self.cur]
        image_dir = None
        question = cur_question[0]
        if len(cur_question) == 3:
            image_dir = cur_question[1]
        self.form.question_label.setText(question)
        if image_dir is not None:
            pixmap = QPixmap(image_dir)
            pixmap = pixmap.scaledToHeight(150)
            self.form.image.setPixmap(pixmap)


class TestForm(QWidget, UiTf):
    def __init__(self):
        super().__init__()
        self.setupUi(self)


class TestAddForm(QWidget, UiTa):
    def __init__(self, name, surname, subject_id, date_of_birth, date, class_id):
        super().__init__()
        self.setupUi(self)
        self.name = name
        self.surname = surname
        self.subject_id = subject_id
        self.date_of_birth = date_of_birth
        self.date = date
        self.class_id = class_id
        self.initUI()

    def initUI(self):
        self.save_button.clicked.connect(self.save_test)
        self.back_button.clicked.connect(self.back)
        self.tot_questions_box.valueChanged.connect(self.questions_changed)
        self.one_test_box.setMaximum(self.tot_questions_box.value())
        self.tableWidget.setColumnCount(1)
        self.tableWidget.setRowCount(3)
        self.tableWidget.setVerticalHeaderLabels(['Текст вопроса', 'Картинка(по необходимости)', 'Правильный ответ'])
        self.questions_changed()

    def questions_changed(self):
        self.len_before = len(os.listdir('images/'))
        self.one_test_box.setMaximum(self.tot_questions_box.value())
        self.one_test_box.setValue(self.tot_questions_box.value())
        self.tableWidget.setColumnCount(self.tot_questions_box.value())
        for i in range(self.tot_questions_box.value()):
            btn = QPushButton(self.tableWidget)
            btn.setText("Добавить картинку")
            btn.clicked.connect(AddImage(i, self))
            self.tableWidget.setCellWidget(1, i, btn)
        self.tableWidget.resizeColumnsToContents()
        self.tableWidget.resizeRowsToContents()

    def save_test(self):
        hw_lst = list()
        self.len_after = len(os.listdir('images/'))
        for i in range(self.tot_questions_box.value()):
            a = self.tableWidget.item(0, i)
            b = self.tableWidget.item(2, i)
            if a is not None:
                if a.text() == '':
                    a = False
                else:
                    a = True
            else:
                a = False
            if b is not None:
                if b.text() == '':
                    b = False
                else:
                    a = True
            else:
                a = False
            if not (a and b):
                self.box = QMessageBox.critical(self, 'Ошибка!', 'Заполните все поля!', QMessageBox.Ok)
                break
            else:
                first = self.tableWidget.item(0, i).text()
                third = self.tableWidget.item(2, i).text()
                if isinstance(self.tableWidget.cellWidget(1, i), QLabel):
                    second = self.tableWidget.cellWidget(1, i).fileName
                    hw_lst.append((first, second, third))
                else:
                    hw_lst.append((first, third))
        else:
            questions = list()
            hw_lst.append(self.one_test_box.value())
            if self.after_test_text.text():
                hw_lst.append(self.after_test_text.text())
            for elem in hw_lst:
                try:
                    a = len(elem)
                    questions.append(elem)
                except Exception:
                    break
            name_of_csv = f"hw_csv/{len(os.listdir('hw_csv/')) + 1}.csv"
            with open(name_of_csv, 'w', newline='') as csvfile:
                writer = csv.writer(
                    csvfile, delimiter=';', quotechar='"',
                    quoting=csv.QUOTE_MINIMAL)
                writer.writerow(['Вопрос', 'Картинка', 'Ответ'])
                rows = []
                for elem in questions:
                    rows.append([elem[0], '' if len(elem) == 2 else elem[1], elem[1] if len(elem) == 2 else elem[2]])
                writer.writerows(rows)

            hw_row = f"{name_of_csv}${self.one_test_box.value()}${self.after_test_text.text()}"
            db = sqlite3.connect('diary_db.sqlite3')
            cur = db.cursor()
            prev = cur.execute(f"""
            SELECT * FROM homework
            WHERE date = '{self.date}' and subject_id = {self.subject_id}
            """).fetchone()
            if prev is None:
                cur.execute(f'''
                INSERT INTO homework (subject_id, homework, date, class_id, is_test)
                VALUES ({self.subject_id}, "{hw_row}", "{self.date}", {self.class_id}, 1)
                ''')
                self.box = QMessageBox.information(self, 'Выполнено!', 'Задание успешно добавлено!', QMessageBox.Ok)
            else:
                cur.execute(f'''
                UPDATE homework
                SET is_test = 1, homework = "{hw_row}"
                WHERE subject_id = {self.subject_id} AND date = "{self.date}"
                ''')
                self.box = QMessageBox.information(self, 'Выполнено!', 'Задание успешно изменено!', QMessageBox.Ok)
            db.commit()
            db.close()
            self.back()

    def back(self):
        self.t_m_a = HomeWorkAddForm(self.name, self.surname, self.subject_id, self.date_of_birth)


class TotalMarksView(QWidget, UiTmv):
    def __init__(self, name, surname, class_id, user_id):
        self.name = name
        self.surname = surname
        self.class_id = class_id
        self.uid = user_id
        super().__init__()
        self.setupUi(self)
        self.initUI()

    def initUI(self):
        self.subject_cb.currentIndexChanged.connect(self.value_changed)
        self.back_button.clicked.connect(self.back)
        db = sqlite3.connect('diary_db.sqlite3')
        cur = db.cursor()
        self.classes = cur.execute(f"""
        SELECT subject_name FROM subjects
        WHERE id = (
        SELECT subject_id from marks
        WHERE user_id = {self.uid} and is_total = 1
        )
        """).fetchall()
        if not self.classes:
            self.show()
            self.box = QMessageBox.critical(self, 'Ошибка!', 'У вас нет итоговых оценок', QMessageBox.Ok)
        else:
            for elem in self.classes:
                self.subject_cb.addItem(elem[0])
            db.close()
            self.value_changed()

    def value_changed(self):
        db = sqlite3.connect('diary_db.sqlite3')
        cur = db.cursor()
        id_of_subject = cur.execute(f"""
        SELECT id FROM subjects
        WHERE subject_name = '{self.subject_cb.currentText()}'
        """).fetchone()[0]
        res = cur.execute(f"""
        SELECT mark FROM marks
        WHERE is_total = 1 AND subject_id = {id_of_subject}
        """).fetchone()[0]
        self.label.setText(f"Итоговая оценка: {res}")
        db.close()

    def back(self):
        self.u_m_w = UserMainWindow(self.name, self.surname, self.class_id, self.uid)
        self.u_m_w.show()
        self.close()


class TotalMarkAdd(QWidget, UiTma):
    def __init__(self, name, surname, date_of_birth, subject_id, prev_form):
        prev_form.close()
        super().__init__()
        self.setupUi(self)
        self.show()
        self.name = name
        self.first = 1
        self.surname = surname
        self.dob = date_of_birth
        self.subject_id = subject_id
        db = sqlite3.connect(DATABASE_NAME)
        cur = db.cursor()
        classes = cur.execute(f"""
        SELECT class_name from classes
        WHERE id in (
        SELECT class_id from schedule
        WHERE schedule like '%{self.name} {self.surname}, {self.dob}%'
        )
        """).fetchall()
        db.close()
        classes = [elem[0] for elem in classes]
        for elem in classes:
            self.class_cb.addItem(elem)
        self.class_changed()
        self.initUI()

    def initUI(self):
        self.back_button.clicked.connect(self.back)
        self.class_cb.currentIndexChanged.connect(self.class_changed)
        self.add_mark_button.clicked.connect(self.add_mark)
        self.student_cb.currentIndexChanged.connect(self.student_changed)

    def add_mark(self):
        if self.avg_mark_line.text() == '':
            info = 'Нельзя выставить итоговую оценку ученику без оценок'
            self.box = QMessageBox.critical(self, 'Ошибка!', info, QMessageBox.Ok)
        else:
            student_info = []
            for elem in self.students:
                if self.student_cb.currentText() in [f"{elem[0]} {elem[1]}, {elem[2]}", f"{elem[0]} {elem[1]}"]:
                    student_info = list(elem)
            uid = student_info[3]
            mark = self.mark_cb.currentText()
            db = sqlite3.connect(DATABASE_NAME)
            cur = db.cursor()
            cur.execute(f"""
            INSERT INTO marks (mark, subject_id, user_id, is_total)
            VALUES ('{mark}', {self.subject_id}, {uid}, 1)
            """)
            db.commit()
            db.close()

    def student_changed(self):
        self.marks_list.clear()
        self.avg_mark_line.clear()
        student_info = []
        db = sqlite3.connect(DATABASE_NAME)
        for elem in self.students:
            if self.student_cb.currentText() in [f"{elem[0]} {elem[1]}, {elem[2]}", f"{elem[0]} {elem[1]}"]:
                student_info = list(elem)
        if not student_info:
            pass
        else:
            cur = db.cursor()
            marks = cur.execute(f"""
            SELECT mark, date FROM marks
            WHERE user_id = {student_info[3]}
            and is_total = 0
            """).fetchall()
            tot = 0
            cnt = 0
            all_marks = []
            for elem in marks:
                if elem[0].isdigit():
                    tot += int(elem[0])
                    cnt += 1
                    all_marks.append(elem)
            if cnt == 0:
                self.box = QMessageBox.information(self, ' ', 'У данного ученика нет оценок', QMessageBox.Ok)
            else:
                for elem in all_marks:
                    mark = elem[0]
                    date = elem[1]
                    self.marks_list.addItem(f"{mark} : {date}")
                self.avg_mark_line.setText(f"{tot / cnt}"[:3])
        db.close()

    def class_changed(self):
        self.student_cb.clear()
        db = sqlite3.connect(DATABASE_NAME)
        cur = db.cursor()
        self.students = cur.execute(f"""
        SELECT name, surname, date_of_birth, id FROM users
        WHERE class_id in (
        SELECT id from classes
        WHERE class_name = '{self.class_cb.currentText()}'
        )
        """).fetchall()
        if len(set([(student[0], student[1]) for student in self.students])) < len(self.students):
            for elem in self.students:
                self.student_cb.addItem(f"{elem[0]} {elem[1]}, {elem[2]}")
        else:
            for elem in self.students:
                self.student_cb.addItem(f"{elem[0]} {elem[1]}")
        if self.first:
            self.first = 0
            self.student_changed()
        db.close()

    def back(self):
        self.t_m_w = TeacherMainWindow(self.name, self.surname, self.subject_id, self.dob)
        self.t_m_w.show()
        self.close()


class MarkAddForm(QWidget, UiMaf):
    def __init__(self, name, surname, subject_id, date_of_birth):
        super().__init__()
        self.name = name
        self.surname = surname
        self.subject_id = subject_id
        self.duplicate = False
        self.date_of_birth = date_of_birth
        self.setupUi(self)
        self.initUI()
        self.date_changed()

    def initUI(self):
        self.add_button.clicked.connect(self.add)
        self.back_button.clicked.connect(self.back)
        self.calendarWidget.selectionChanged.connect(self.date_changed)
        self.class_cb.currentIndexChanged.connect(self.class_changed)

    def date_changed(self):
        self.class_cb.clear()
        self.date = self.calendarWidget.selectedDate().toString('dd.MM.yyyy')
        self.classes = list()
        db = sqlite3.connect(DATABASE_NAME)
        cur = db.cursor()
        res = cur.execute(f"""
        SELECT class_id FROM schedule
        WHERE schedule like '%{self.name} {self.surname}, {self.date_of_birth}%' and date = '{self.date}'""").fetchall()
        for i in range(len(res)):
            tmp = res[i][0]
            class_name = cur.execute(f"""
            SELECT class_name FROM classes
            WHERE id = {tmp}
            """).fetchone()[0]
            self.classes.append((tmp, class_name))
        for elem in self.classes:
            self.class_cb.addItem(elem[1])
        self.class_changed()
        db.close()

    def back(self):
        self.t_m_w = TeacherMainWindow(self.name, self.surname, self.subject_id, self.date_of_birth)
        self.t_m_w.show()
        self.close()

    def add(self):
        student_id = ''
        dct = {'Пропуск по неуваж. причине': 'Н',
               'Пропуск по уваж. причине': 'У',
               'Пропуск по болезни': 'Б'}
        mark = self.mark_combobox.currentText()
        if mark in dct:
            mark = dct[mark]
        if self.student_cb.currentText() == '':
            self.box = QMessageBox.critical(self, 'Ошибка', 'Выберите ученика!', QMessageBox.Ok)
        else:
            for elem in self.res:
                if self.student_cb.currentText() == f'{elem[0]} {elem[1]}' + (f", {elem[2]}" if self.duplicate else ''):
                    student_id = elem[3]
            db = sqlite3.connect(DATABASE_NAME)
            cur = db.cursor()
            cur.execute(f"""
            INSERT INTO marks (mark, subject_id, user_id, date)
            VALUES ('{mark}', {self.subject_id}, {student_id}, '{self.date}')
            """)
            db.commit()
            db.close()
            self.box = QMessageBox.information(self, 'Выполнено!', 'Информация успешно добавлена', QMessageBox.Ok)

    def class_changed(self):
        self.duplicates = False
        self.student_cb.clear()
        class_id = ''
        for elem in self.classes:
            if elem[1] == self.class_cb.currentText():
                class_id = elem[0]
                break
        db = sqlite3.connect(DATABASE_NAME)
        cur = db.cursor()
        if class_id != '':
            self.res = cur.execute(f"""
            SELECT name, surname, date_of_birth, id FROM users
            WHERE class_id = {class_id}
            """).fetchall()
            names_and_surnames = [(elem[0], elem[1]) for elem in self.res]
            counter = Counter(names_and_surnames)
            a = list(dict(counter).values())
            if 2 in a:
                self.duplicate = True
                for elem in self.res:
                    self.student_cb.addItem(f"{elem[0]} {elem[1]}, {elem[2]}")
            else:
                for elem in self.res:
                    self.student_cb.addItem(f"{elem[0]} {elem[1]}")
        db.close()


class HomeWorkAddForm(QWidget, UiHwaf):
    def __init__(self, name, surname, subject_id, date_of_birth):
        self.name = name
        self.surname = surname
        self.subject_id = subject_id
        self.date_of_birth = date_of_birth
        super().__init__()
        self.setupUi(self)
        self.initUI()
        self.date_changed()

    def initUI(self):
        self.calendarWidget.selectionChanged.connect(self.date_changed)
        self.add_hw_button.clicked.connect(self.add_hw)
        self.back_button.clicked.connect(self.back)
        self.add_test_button.clicked.connect(self.open_test_form)

    def open_test_form(self):
        db = sqlite3.connect('diary_db.sqlite3')
        cur = db.cursor()
        class_id = cur.execute(f"""
        SELECT id from classes
        WHERE class_name = '{self.class_cb.currentText()}'
        """).fetchone()
        if class_id is None:
            self.box = QMessageBox.critical(self, 'Ошибка!', 'Выберите класс!', QMessageBox.Ok)
        else:
            class_id = class_id[0]
            date = self.calendarWidget.selectedDate().toString('dd.MM.yyyy')
            db.close()
            self.t_c_f = TestAddForm(self.name, self.surname, self.subject_id, self.date_of_birth, date, class_id)
            self.t_c_f.show()
            self.close()

    def back(self):
        self.t_m_w = TeacherMainWindow(self.name, self.surname, self.subject_id, self.date_of_birth)
        self.t_m_w.show()

        self.close()

    def date_changed(self):
        # Функция,вызываемая при смене даты и при инициализации
        self.class_cb.clear()
        self.date = self.calendarWidget.selectedDate().toString('dd.MM.yyyy')
        db = sqlite3.connect(DATABASE_NAME)
        cur = db.cursor()
        res = cur.execute(f"""
                SELECT class_id FROM schedule
                WHERE schedule like '%{self.name} {self.surname}, {self.date_of_birth}%' AND date = '{self.date}'
                """).fetchall()
        for i in range(len(res)):
            class_to_add = cur.execute(f"""
            SELECT class_name FROM classes
            WHERE id = {res[i][0]}
            """).fetchone()[0]
            self.class_cb.addItem(class_to_add)

    def add_hw(self):
        text = self.hw_line.text()
        if not text:
            self.box = QMessageBox.critical(self, 'Ошибка', 'заполните поле ДЗ', QMessageBox.Ok)
        else:
            db = sqlite3.connect(DATABASE_NAME)
            cur = db.cursor()
            class_id = cur.execute(f"""
            SELECT id FROM classes
            WHERE class_name = '{self.class_cb.currentText()}'
            """).fetchone()[0]
            prev = cur.execute(f"""
            SELECT * FROM homework
            WHERE class_id = {class_id} AND subject_id = {self.subject_id} AND date = '{self.date}'
            """).fetchall()
            if prev:
                cur.execute(f"""
                UPDATE homework
                SET homework = '{self.hw_line.text()}'
                """)
                info = 'Домашнее задание изменено!'
            else:
                cur.execute(f"""
                INSERT INTO homework (subject_id, homework, date, class_id)
                VALUES ({self.subject_id}, '{self.hw_line.text()}', '{self.date}', {class_id})
                """)
                info = 'Домашнее задание добавлено!'
            db.commit()
            db.close()
            self.box = QMessageBox.information(self, 'Выполнено', info, QMessageBox.Ok)


class TeacherMainWindow(QMainWindow, UiTmw):
    def __init__(self, name, surname, subject_id, date_of_birth):
        super().__init__()
        db = sqlite3.connect(DATABASE_NAME)
        cur = db.cursor()
        self.r_f_s = cur.execute(f"""
        SELECT lesson_time FROM ring_first_shift
        """).fetchall()
        for i in range(len(self.r_f_s)):
            self.r_f_s[i] = self.r_f_s[i][0]
        self.r_s_s = cur.execute(f"""
        SELECT lesson_time FROM ring_second_shift
        """).fetchall()
        for i in range(len(self.r_s_s)):
            self.r_s_s[i] = self.r_s_s[i][0]
        self.subject_name = cur.execute(f"""
        SELECT subject_name from subjects
        WHERE id = {subject_id}
        """).fetchone()[0]
        self.first = 1
        self.setupUi(self)
        self.name = name
        self.subject_id = subject_id
        self.surname = surname
        self.date_of_birth = date_of_birth
        self.initUI()
        self.date_changed()

    def initUI(self):
        self.add_final_marks.clicked.connect(self.add_final)
        self.welcome_label.setText(f"Добро пожаловать, {self.name} {self.surname}!")
        self.lessons_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.logout_button.clicked.connect(self.logout)
        self.add_marks_button.clicked.connect(self.add_marks)
        self.add_hw_button.clicked.connect(self.add_hw)
        self.calendarWidget.selectionChanged.connect(self.date_changed)

    def add_final(self):
        self.tma = TotalMarkAdd(self.name, self.surname, self.date_of_birth, self.subject_id, self)
        self.tma.show()
        self.close()

    def date_changed(self):
        self.lessons_table.clear()
        self.lessons_table.setRowCount(0)
        self.lessons_table.setColumnCount(0)
        
        date = self.calendarWidget.selectedDate().toString('dd.MM.yyyy')
        db = sqlite3.connect(DATABASE_NAME)
        cur = db.cursor()
        res = cur.execute(f"""
        SELECT schedule, class_id FROM schedule
        WHERE schedule like '%{self.name} {self.surname}, {self.date_of_birth}%' AND date = '{date}'
        """).fetchall()
        if not res:
            pass
        else:
            lessons = []
            for i in range(len(res)):
                schedule = res[i][0]
                class_id = int(res[i][1])
                shift = cur.execute(f"""
                SELECT shift FROM classes
                WHERE id = {class_id}
                """).fetchone()[0]
                for index, j in enumerate(schedule.split(';')):
                    num = int(j.split(' : ')[0])
                    class_name = cur.execute(f"""
                    SELECT class_name from classes
                    WHERE id = {class_id}
                    """).fetchone()[0]
                    if self.subject_name == j.split(' : ')[1] and \
                            j.split(' : ')[2] == f"{self.name} {self.surname}, {self.date_of_birth}":
                        lessons.append([num, shift, class_name])
            self.lessons_table.setRowCount(len(lessons))
            self.lessons_table.setColumnCount(4)
            self.lessons_table.setHorizontalHeaderLabels(['№ урока', 'Смена', 'Время урока', 'Класс'])
            self.lessons_table.setVerticalHeaderLabels([''] * self.lessons_table.rowCount())
            lessons = sorted(lessons, key=lambda x: (x[1], x[0]))
            for r_c, row in enumerate(lessons):
                new = [row[0], row[1], self.r_f_s[row[0] - 1] if row[1] == 1 else self.r_s_s[row[0] - 1], row[2]]
                for c_c, col in enumerate(new):
                    self.lessons_table.setItem(r_c, c_c, QTableWidgetItem(str(col)))
            self.lessons_table.resizeColumnsToContents()
        db.close()

    def add_hw(self):
        self.hw_a_f = HomeWorkAddForm(self.name, self.surname, self.subject_id, self.date_of_birth)
        self.hw_a_f.show()
        self.close()

    def add_marks(self):
        self.m_a_f = MarkAddForm(self.name, self.surname, self.subject_id, self.date_of_birth)
        self.m_a_f.show()
        self.close()

    def logout(self):
        self.r_f = RegistrationForm()
        self.r_f.show()
        self.close()


class UserMainWindow(QMainWindow, UiUw):
    def __init__(self, name, surname, class_id, user_id):
        super().__init__()
        self.user_id = user_id
        self.name = name
        self.surname = surname
        self.class_id = class_id
        db = sqlite3.connect(DATABASE_NAME)
        cur = db.cursor()
        self.shift = cur.execute(f"""
        SELECT shift FROM classes
        WHERE id = {class_id}
        """).fetchone()[0]
        table_name = 'ring_first_shift' if self.shift == 1 else 'ring_second_shift'
        self.rings = cur.execute(f"""SELECT lesson_time FROM {table_name}""").fetchall()
        for i in range(len(self.rings)):
            self.rings[i] = self.rings[i][0]
        db.close()
        super().__init__()
        self.setupUi(self)
        self.date_changed()
        self.initUI()

    def initUI(self):
        self.view_marks_button.clicked.connect(self.view_total_marks)
        self.calendarWidget.selectionChanged.connect(self.date_changed)
        self.schedule_on_day.setEditTriggers(QTableWidget.NoEditTriggers)
        self.marks_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.h_w_schedule.setEditTriggers(QTableWidget.NoEditTriggers)
        self.logout_button.clicked.connect(self.logout)
        self.welcome_label.setText(f"Добро пожаловать, {self.name} {self.surname}!")

    def view_total_marks(self):
        self.hide()
        self.t_m_v = TotalMarksView(self.name, self.surname, self.class_id, self.user_id)
        self.t_m_v.show()
        self.close()
        
    def date_changed(self):
        self.schedule_on_day.clear()
        self.schedule_on_day.setRowCount(0)
        self.schedule_on_day.setColumnCount(0)
        self.h_w_schedule.clear()
        self.h_w_schedule.setRowCount(0)
        self.h_w_schedule.setColumnCount(0)
        
        date = self.calendarWidget.selectedDate().toString('dd.MM.yyyy')
        db = sqlite3.connect(DATABASE_NAME)
        cur = db.cursor()
        schedule = cur.execute(f"""
        SELECT schedule FROM schedule
        WHERE date = '{date}' AND class_id = '{self.class_id}'
        """).fetchone()
        if schedule is None:
            pass
        else:

            # Добавление оценок в таблицу
            marks = cur.execute(f"""
                    SELECT mark, subject_id FROM marks
                    WHERE date = '{date}' and user_id = {self.user_id}
                    """).fetchall()
            marks_changed = dict()
            for elem in marks:
                subject_name = cur.execute(f"""
                        SELECT subject_name FROM subjects
                        WHERE id = {elem[1]}
                        """).fetchone()[0]
                if subject_name in marks_changed:
                    marks_changed[subject_name] += f' / {elem[0]}'
                else:
                    marks_changed[subject_name] = elem[0]
            marks_changed = sorted(list(marks_changed.items()), key=lambda x: x[0])
            self.marks_table.setRowCount(len(marks_changed))
            self.marks_table.setColumnCount(2)
            for index, elem in enumerate(marks_changed):
                self.marks_table.setItem(index, 0, QTableWidgetItem(elem[0]))
                self.marks_table.setItem(index, 1, QTableWidgetItem(elem[1]))

            # Добавление расписания в таблицу
            self.schedule_on_day.setRowCount(len(schedule[0].split(';')))
            self.schedule_on_day.setColumnCount(4)
            for row, elem in enumerate(schedule[0].split(';')):
                to_ins = []
                num, subject, name_and_birth = elem.split(':')
                num = int(num)
                name = name_and_birth.split(', ')[0]
                lesson_time = self.rings[num - 1]
                to_ins.extend([num, lesson_time, subject, name])
                self.schedule_on_day.setHorizontalHeaderLabels(['№ урока', 'Время урока', 'Предмет', 'Учитель'])
                self.schedule_on_day.setVerticalHeaderLabels([''] * 9)
                for col, i in enumerate(to_ins):
                    self.schedule_on_day.setItem(row, col, QTableWidgetItem(str(i)))

            # Добавление ДЗ в таблицу
            set_subjects = set()
            for elem in schedule[0].split(';'):
                set_subjects.add(elem.split(' : ')[1])
            set_subjects = sorted(list(set_subjects))
            homeworks = list()
            for elem in set_subjects:
                subject_id = cur.execute(f"""
                SELECT id from subjects
                WHERE subject_name = '{elem}'
                """).fetchone()[0]
                hw = cur.execute(f"""
                SELECT homework, is_test FROM homework
                WHERE date = '{date}' AND subject_id = {subject_id} AND class_id = {self.class_id}
                """).fetchone()
                if hw is not None:
                    homeworks.append([elem, hw[0], hw[1]])
            self.h_w_schedule.setRowCount(len(homeworks))
            self.h_w_schedule.setColumnCount(2)
            self.h_w_schedule.setHorizontalHeaderLabels(['Название предмета', 'Задание'])
            self.h_w_schedule.setVerticalHeaderLabels([''] * self.h_w_schedule.rowCount())
            for index, i in enumerate(homeworks):
                pass
                self.h_w_schedule.setItem(index, 0, QTableWidgetItem(i[0]))
                if i[2] == 1:
                    btn = QPushButton(self.h_w_schedule)
                    btn.setText('Пройти тест')
                    btn.clicked.connect(Test(self, i[1], self.user_id, i[0], date))
                    self.h_w_schedule.setCellWidget(index, 1, btn)
                else:
                    self.h_w_schedule.setItem(index, 1, QTableWidgetItem(i[1]))

        # Меняем размер таблицы под содержимое
        self.h_w_schedule.resizeColumnsToContents()
        self.marks_table.resizeColumnsToContents()
        self.schedule_on_day.resizeColumnsToContents()
        db.commit()
        db.close()

    def logout(self):
        self.r_f = RegistrationForm()
        self.r_f.show()
        self.close()


class ScheduleAddForm(QWidget, UiAsf):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.initUI()

    def initUI(self):
        self.back_button.clicked.connect(self.back)
        self.cb1.currentIndexChanged.connect(self.value_changed1)
        self.cb2.currentIndexChanged.connect(self.value_changed2)
        self.cb3.currentIndexChanged.connect(self.value_changed3)
        self.cb4.currentIndexChanged.connect(self.value_changed4)
        self.cb5.currentIndexChanged.connect(self.value_changed5)
        self.cb6.currentIndexChanged.connect(self.value_changed6)
        self.cb7.currentIndexChanged.connect(self.value_changed7)
        self.cb8.currentIndexChanged.connect(self.value_changed8)
        self.cb9.currentIndexChanged.connect(self.value_changed9)
        self.change_button.clicked.connect(self.change)
        db = sqlite3.connect(DATABASE_NAME)
        cur = db.cursor()
        classes = cur.execute("""
        SELECT class_name FROM classes
            WHERE class_name != 'admin'
        """).fetchall()
        for elem in classes:
            self.class_cb.addItem(elem[0])
        lst_res = ['Нет']
        res = cur.execute("""
        SELECT subject_name FROM subjects
        """).fetchall()
        db.close()
        for elem in res:
            lst_res.append(elem[0])
        self.cb1.addItems(lst_res)
        self.cb2.addItems(lst_res)
        self.cb3.addItems(lst_res)
        self.cb4.addItems(lst_res)
        self.cb5.addItems(lst_res)
        self.cb6.addItems(lst_res)
        self.cb7.addItems(lst_res)
        self.cb8.addItems(lst_res)
        self.cb9.addItems(lst_res)

    def change(self):
        date = self.calendarWidget.selectedDate().toString('dd.MM.yyyy')
        class_name = self.class_cb.currentText()
        db = sqlite3.connect(DATABASE_NAME)
        cur = db.cursor()
        idd = cur.execute(f"""
        SELECT id FROM classes
            WHERE class_name = '{class_name}'
        """).fetchone()[0]
        rows = list()
        rows.append(f"1 : {self.cb1.currentText()} : {self.tcb1.currentText()}")
        rows.append(f"2 : {self.cb2.currentText()} : {self.tcb2.currentText()}")
        rows.append(f"3 : {self.cb3.currentText()} : {self.tcb3.currentText()}")
        rows.append(f"4 : {self.cb4.currentText()} : {self.tcb4.currentText()}")
        rows.append(f"5 : {self.cb5.currentText()} : {self.tcb5.currentText()}")
        rows.append(f"6 : {self.cb6.currentText()} : {self.tcb6.currentText()}")
        rows.append(f"7 : {self.cb7.currentText()} : {self.tcb7.currentText()}")
        rows.append(f"8 : {self.cb8.currentText()} : {self.tcb8.currentText()}")
        rows.append(f"9 : {self.cb9.currentText()} : {self.tcb9.currentText()}")
        changed_rows = []
        for elem in rows:
            spl = elem.split(':')
            if spl[1][:4] == ' Нет':
                pass
            else:
                changed_rows.append(elem)
        schedule = ';'.join(changed_rows)
        prev = cur.execute(f"""
        SELECT * FROM schedule
            WHERE date = '{date}' AND class_id = {idd}
        """).fetchall()
        if prev:
            cur.execute(f"""
            UPDATE schedule
            SET schedule = '{schedule}'
            WHERE date = '{date}' AND class_id = {idd}
            """)
            db.commit()
            self.box = QMessageBox.information(self, 'Выполнено!', 'Расписание успешно изменено!', QMessageBox.Ok)
        else:
            cur.execute(f"""
            INSERT INTO schedule (date, class_id, schedule)
            VALUES ('{date}', {idd}, '{schedule}')
            """)
            db.commit()
            self.box = QMessageBox.information(self, 'Выполнено!', 'Расписание успешно добавлено!', QMessageBox.Ok)
        db.close()

    def value_changed1(self):
        self.tcb1.clear()
        if self.cb1.currentText() == 'Нет':
            pass
        else:
            db = sqlite3.connect(DATABASE_NAME)
            cur = db.cursor()
            res = cur.execute(f"""
            SELECT name, surname, date_of_birth FROM users
            WHERE subject_id = (
            SELECT id FROM subjects
            WHERE subject_name = '{self.cb1.currentText()}'
            )
            """).fetchall()
            for elem in res:
                self.tcb1.addItem(f"{elem[0]} {elem[1]}, {elem[2]}")
            db.close()

    def value_changed2(self):
        self.tcb2.clear()
        if self.cb2.currentText() == 'Нет':
            pass
        else:
            db = sqlite3.connect(DATABASE_NAME)
            cur = db.cursor()
            res = cur.execute(f"""
            SELECT name, surname, date_of_birth FROM users
            WHERE subject_id = (
            SELECT id FROM subjects
            WHERE subject_name = '{self.cb2.currentText()}'
            )
            """).fetchall()
            for elem in res:
                self.tcb2.addItem(f"{elem[0]} {elem[1]}, {elem[2]}")
            db.close()

    def value_changed3(self):
        self.tcb3.clear()
        if self.cb3.currentText() == 'Нет':
            pass
        else:
            db = sqlite3.connect(DATABASE_NAME)
            cur = db.cursor()
            res = cur.execute(f"""
            SELECT name, surname, date_of_birth FROM users
            WHERE subject_id = (
            SELECT id FROM subjects
            WHERE subject_name = '{self.cb3.currentText()}'
            )
            """).fetchall()
            for elem in res:
                self.tcb3.addItem(f"{elem[0]} {elem[1]}, {elem[2]}")
            db.close()

    def value_changed4(self):
        self.tcb4.clear()
        if self.cb4.currentText() == 'Нет':
            pass
        else:
            db = sqlite3.connect(DATABASE_NAME)
            cur = db.cursor()
            res = cur.execute(f"""
            SELECT name, surname, date_of_birth FROM users
            WHERE subject_id = (
            SELECT id FROM subjects
            WHERE subject_name = '{self.cb4.currentText()}'
            )
            """).fetchall()
            for elem in res:
                self.tcb4.addItem(f"{elem[0]} {elem[1]}, {elem[2]}")
            db.close()

    def value_changed5(self):
        self.tcb5.clear()
        if self.cb5.currentText() == 'Нет':
            pass
        else:
            db = sqlite3.connect(DATABASE_NAME)
            cur = db.cursor()
            res = cur.execute(f"""
            SELECT name, surname, date_of_birth FROM users
            WHERE subject_id = (
            SELECT id FROM subjects
            WHERE subject_name = '{self.cb5.currentText()}'
            )
            """).fetchall()
            for elem in res:
                self.tcb5.addItem(f"{elem[0]} {elem[1]}, {elem[2]}")
            db.close()

    def value_changed6(self):
        self.tcb6.clear()
        if self.cb6.currentText() == 'Нет':
            pass
        else:
            db = sqlite3.connect(DATABASE_NAME)
            cur = db.cursor()
            res = cur.execute(f"""
            SELECT name, surname, date_of_birth FROM users
            WHERE subject_id = (
            SELECT id FROM subjects
            WHERE subject_name = '{self.cb6.currentText()}'
            )
            """).fetchall()
            for elem in res:
                self.tcb6.addItem(f"{elem[0]} {elem[1]}, {elem[2]}")
            db.close()

    def value_changed7(self):
        self.tcb7.clear()
        if self.cb7.currentText() == 'Нет':
            pass
        else:
            db = sqlite3.connect(DATABASE_NAME)
            cur = db.cursor()
            res = cur.execute(f"""
            SELECT name, surname, date_of_birth FROM users
            WHERE subject_id = (
            SELECT id FROM subjects
            WHERE subject_name = '{self.cb7.currentText()}'
            )
            """).fetchall()
            for elem in res:
                self.tcb7.addItem(f"{elem[0]} {elem[1]}, {elem[2]}")
            db.close()

    def value_changed8(self):
        self.tcb8.clear()
        if self.cb8.currentText() == 'Нет':
            pass
        else:
            db = sqlite3.connect(DATABASE_NAME)
            cur = db.cursor()
            res = cur.execute(f"""
            SELECT name, surname, date_of_birth FROM users
            WHERE subject_id = (
            SELECT id FROM subjects
            WHERE subject_name = '{self.cb8.currentText()}'
            )
            """).fetchall()
            for elem in res:
                self.tcb8.addItem(f"{elem[0]} {elem[1]}, {elem[2]}")
            db.close()

    def value_changed9(self):
        self.tcb9.clear()
        if self.cb9.currentText() == 'Нет':
            pass
        else:
            db = sqlite3.connect(DATABASE_NAME)
            cur = db.cursor()
            res = cur.execute(f"""
            SELECT name, surname, date_of_birth FROM users
            WHERE subject_id = (
            SELECT id FROM subjects
            WHERE subject_name = '{self.cb9.currentText()}'
            )
            """).fetchall()
            for elem in res:
                self.tcb9.addItem(f"{elem[0]} {elem[1]}, {elem[2]}")
            db.close()

    def back(self):
        self.s_f = SelectionForm()
        self.s_f.show()
        self.close()


class RingChangeForm(QWidget, UiSrf):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.initUI()

    def initUI(self):
        self.change_button.clicked.connect(self.change)
        self.back_button.clicked.connect(self.back)

    def back(self):
        self.s_f = SelectionForm()
        self.s_f.show()
        self.close()

    def change(self):
        res = list()
        res.append(self.line_one.text())
        res.append(self.line_two.text())
        res.append(self.line_three.text())
        res.append(self.line_four.text())
        res.append(self.line_five.text())
        res.append(self.line_six.text())
        res.append(self.line_seven.text())
        res.append(self.line_eight.text())
        res.append(self.line_nine.text())
        if '' in res:
            self.box = QMessageBox.critical(self, 'Ошибка', 'Заполните все поля!', QMessageBox.Ok)
        else:
            db = sqlite3.connect(DATABASE_NAME)
            cur = db.cursor()
            if self.first_shift.isChecked():
                table_name = 'ring_first_shift'
            else:
                table_name = 'ring_second_shift'
            cur.execute(f"""UPDATE {table_name}
            SET lesson_time = (
            CASE lesson_number
                WHEN 1 THEN '{res[0]}'
                WHEN 2 THEN '{res[1]}'
                WHEN 3 THEN '{res[2]}'
                WHEN 4 THEN '{res[3]}'
                WHEN 5 THEN '{res[4]}'
                WHEN 6 THEN '{res[5]}'
                WHEN 7 THEN '{res[6]}'
                WHEN 8 THEN '{res[7]}'
                ELSE '{res[8]}'
            END)""")
            db.commit()
            db.close()
            self.box = QMessageBox.information(self, 'Выполнено!', 'Расписание успешно изменено', QMessageBox.Ok)


class UserChangeForm(QWidget, UiUc):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.initUI()
        self.to_change = []
        self.id = None

    def initUI(self):
        self.back_button.clicked.connect(self.back)
        self.find_button.clicked.connect(self.find)
        self.apply_button.clicked.connect(self.apply_changes)

    def apply_changes(self):
        new = []
        if self.tableWidget.rowCount() == 0:
            self.box = QMessageBox.critical(self, 'Ошибка', 'Нечего изменять!', QMessageBox.Ok)
        else:
            for i in range(5):
                new.append(self.tableWidget.item(0, i).text())
            if new == self.to_change:
                self.box = QMessageBox.critical(self, 'Ошибка', 'Введите новые значения!', QMessageBox.Ok)
            else:
                try:
                    db = sqlite3.connect(DATABASE_NAME)
                    cur = db.cursor()
                    cur.execute(f"""
                    UPDATE users
                    SET name = '{new[0]}', surname = '{new[1]}', login = '{new[2]}', password = '{new[3]}', date_of_birth = '{new[4]}'
                    WHERE id = {self.id}
                    """)
                    db.commit()
                    self.box = QMessageBox.information(self, 'Выполнено!', 'Данные успешно изменены', QMessageBox.Ok)
                    self.find()
                except Exception:
                    self.box = QMessageBox.critical(self, 'Ошибка', 'Данный логин занят', QMessageBox.Ok)
                    self.find()

    def find(self):
        if self.login_line.text() == '':
            self.box = QMessageBox.critical(self, 'Ошибка', 'Введите логин', QMessageBox.Ok)
        else:
            db = sqlite3.connect(DATABASE_NAME)
            cur = db.cursor()
            res = cur.execute(f"""
            SELECT * FROM users
            WHERE login = '{self.login_line.text()}'
            """).fetchone()
            if res is None:
                self.box = QMessageBox.critical(self, 'Ошибка', 'Пользователь не найден', QMessageBox.Ok)
            elif self.login_line.text() == 'admin':
                self.box = QMessageBox.critical(self, 'Ошибка', 'Нельзя изменить данные администратора', QMessageBox.Ok)
            else:
                self.tableWidget.setColumnCount(5)
                self.tableWidget.setRowCount(1)
                self.tableWidget.setHorizontalHeaderLabels(['Имя', 'Фамилия', 'Логин', 'Пароль', 'Дата рождения'])
                self.id = res[0]
                self.to_change = [res[1], res[2], res[3], res[4], res[7]]
                for index, elem in enumerate(self.to_change):
                    self.tableWidget.setItem(0, index, QTableWidgetItem(elem))

    def back(self):
        self.s_f = SelectionForm()
        self.s_f.show()
        self.close()


class ClassChangeForm(QWidget, UiCch):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.initUI()

    def initUI(self):
        db = sqlite3.connect(DATABASE_NAME)
        cur = db.cursor()
        res = cur.execute("""
        SELECT class_name from classes
            WHERE class_name != 'admin'""").fetchall()
        db.close()
        for elem in res:
            self.comboBox.addItem(elem[0])
        self.change_button.clicked.connect(self.change)
        self.back_button.clicked.connect(self.back)

    def back(self):
        self.s_f = SelectionForm()
        self.s_f.show()
        self.close()

    def change(self):
        db = sqlite3.connect(DATABASE_NAME)
        cur = db.cursor()
        res = cur.execute(f"""
        SELECT * FROM classes
            WHERE class_name = '{self.comboBox.currentText()}'""").fetchone()
        if res[-1] != (1 if self.first_shift.isChecked() else 2):
            cur.execute(f"""
            UPDATE classes
                SET shift = {1 if self.first_shift.isChecked() else 2},
                class_name = '{res[1] if self.new_name_line.text() == '' else self.new_name_line.text()}'
            WHERE class_name = '{self.comboBox.currentText()}'
            """)
            db.commit()
            self.box = QMessageBox.information(self, 'Выполнено', 'Данные успешно изменены', QMessageBox.Ok)
        else:
            if self.new_name_line.text() == '':
                self.box = QMessageBox.critical(self, 'Ошибка', 'Новое название не должно быть пустым', QMessageBox.Ok)
            elif self.comboBox.currentText() == self.new_name_line.text():
                self.box = QMessageBox.critical(self, 'Ошибка', 'Новое имя не должно совпадать со старым', QMessageBox.Ok)
            else:
                try:
                    cur.execute(f"""
                    UPDATE classes
                        SET class_name = '{self.new_name_line.text()}',
                        shift = {1 if self.first_shift.isChecked() else 2}
                    WHERE class_name = '{self.comboBox.currentText()}'""")
                    db.commit()
                except Exception:
                    self.box = QMessageBox.critical(self, 'Ошибка', 'Данное название уже занято', QMessageBox.Ok)
                else:
                    self.box = QMessageBox.information(self, 'Выполнено!', 'Название изменено', QMessageBox.Ok)
        self.comboBox.clear()
        res = cur.execute("""
        SELECT class_name from classes
            WHERE class_name != 'admin'""").fetchall()
        for elem in res:
            self.comboBox.addItem(elem[0])
        db.close()


class UserRemoveForm(QWidget, UiUrf):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.initUI()
        self.res = None
        self.classes = None

    def initUI(self):
        self.tableWidget.setEditTriggers(QTableWidget.NoEditTriggers)
        self.delete_button.clicked.connect(self.delete_user)
        self.find_button.clicked.connect(self.find)
        self.back_button.clicked.connect(self.back)

    def back(self):
        self.s_f = SelectionForm()
        self.s_f.show()
        self.close()

    def find(self):
        if self.login_line.text() == '':
            self.box = QMessageBox.critical(self, 'Ошибка', 'Введите логин!', QMessageBox.Ok)
        else:
            db = sqlite3.connect(DATABASE_NAME)
            cur = db.cursor()
            self.res = cur.execute(f"""
            SELECT * FROM users
                WHERE login = '{self.login_line.text()}'""").fetchone()
            if self.res is None:
                self.box = QMessageBox.critical(self, 'Ошибка', 'Пользователь не найден', QMessageBox.Ok)
            else:
                self.res = list(self.res)
                if self.res[-3] is None:
                    pass
                else:
                    self.classes = list(cur.execute(f"""
                    SELECT class_name FROM classes
                        WHERE id = {self.res[-3]}""").fetchone())
                    if self.classes is not None:
                        self.classes = self.classes[0]
                if self.classes == 'admin':
                    self.res[5] = 'Администратор'
                else:
                    self.res[5] = 'Ученик' if self.res[5] is not None else 'Учитель'
                if self.res is None:
                    self.box = QMessageBox.critical(self, "Ошибка", "Данный пользователь не найден", QMessageBox.Ok)
                else:
                    self.res = [self.res[1], self.res[2], self.res[5], self.res[7]]
                    self.tableWidget.setColumnCount(4)
                    self.tableWidget.setHorizontalHeaderLabels(['Имя', 'Фамилия', 'Статус', 'Дата рождения'])
                    self.tableWidget.setRowCount(1)
                    for index, elem in enumerate(self.res):
                        self.tableWidget.setItem(0, index, QTableWidgetItem(elem))
                    self.tableWidget.resizeColumnsToContents()
            db.close()

    def delete_user(self):
        if self.res is None:
            self.box = QMessageBox.critical(self, "Ошибка", "Поиск не был произведён", QMessageBox.Ok)
        else:
            if self.classes == 'admin':
                self.box = QMessageBox.critical(self, 'Ошибка', 'Нельзя удалить администратора', QMessageBox.Ok)
                self.tableWidget.clear()
                self.tableWidget.setRowCount(0)
                self.tableWidget.setColumnCount(0)
                self.res = None
                self.classes = None
            else:
                db = sqlite3.connect(DATABASE_NAME)
                cur = db.cursor()
                cur.execute(f"""
                DELETE FROM users
                    WHERE login = '{self.login_line.text()}'""")
                db.commit()
                self.box = QMessageBox.information(self, 'Выполнено!', 'Пользователь успешно удалён')
                self.tableWidget.clear()
                self.tableWidget.setRowCount(0)
                self.tableWidget.setColumnCount(0)
                self.res = None
                self.classes = None
                db.close()


class ClassRemoveForm(QWidget, UiCrf):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.initUI()

    def initUI(self):
        self.back_button.clicked.connect(self.back)
        self.delete_button.clicked.connect(self.delete)
        db = sqlite3.connect(DATABASE_NAME)
        cur = db.cursor()
        res = cur.execute("""
        SELECT class_name FROM classes
            WHERE class_name != 'admin'""").fetchall()
        db.close()
        if not res:
            self.box = QMessageBox.critical(self, 'Ошибка', 'Нет классов для удаления.', QMessageBox.Ok)
            self.s_f = SelectionForm()
            self.s_f.show()
            self.close()
        else:
            self.show()
            for elem in res:
                self.class_combo_box.addItem(elem[0])

    def delete(self):
        db = sqlite3.connect(DATABASE_NAME)
        cur = db.cursor()
        res = cur.execute(f"""
        SELECT id FROM classes
            WHERE class_name = '{self.class_combo_box.currentText()}'""").fetchone()[0]
        cur.execute(f"""
        DELETE FROM users
            WHERE class_id = {res}""")
        db.commit()
        cur.execute(f"""
        DELETE FROM classes
            WHERE id = {res}""")
        db.commit()
        db.close()
        self.box = QMessageBox.information(self, 'Выполнено', 'Класс и все пользователи в нём удалены', QMessageBox.Ok)
        self.s_f = SelectionForm()
        self.s_f.show()
        self.close()

    def back(self):
        self.s_f = SelectionForm()
        self.s_f.show()
        self.close()


class TeacherRegForm(QWidget, UiTaf):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.initUI()

    def initUI(self):
        self.back_button.clicked.connect(self.back)
        self.reg_button.clicked.connect(self.add_teacher)

    def back(self):
        self.c_f = SelectionForm()
        self.c_f.show()
        self.close()

    def add_teacher(self):
        if self.name_line.text() == '' or self.surname_line.text() == '' or self.login_line.text() == '' \
                or self.pword_line.text() == '' or self.subject_line.text() == '':
            self.box = QMessageBox.critical(self, "Ошибка", "Поля не должны быть пустыми.", QMessageBox.Ok)
        db = sqlite3.connect(DATABASE_NAME)
        cur = db.cursor()
        date = self.bdate_edit.date().toString('dd.MM.yyyy')
        res = cur.execute(f"""
        SELECT id FROM subjects
            WHERE subject_name = '{self.subject_line.text()}'""").fetchone()
        if res is None:
            cur.execute(f"""
            INSERT INTO subjects (subject_name)
                VALUES ('{self.subject_line.text()}')""")
            db.commit()
            res = cur.execute(f"""
            SELECT id FROM subjects
                WHERE subject_name = '{self.subject_line.text()}'""").fetchone()
        try:
            name = self.name_line.text()
            surname = self.surname_line.text()
            login = self.login_line.text()
            password = self.pword_line.text()
            cur.execute(f"""
            INSERT INTO users (name, surname, login, password, subject_id, date_of_birth)
                VALUES (
                '{name}', '{surname}', '{login}', '{password}', {res[0]}, '{date}'
                )
                """)
            db.commit()
            db.close()
        except Exception:
            self.box = QMessageBox.critical(self, "Ошибка", "Данный логин уже занят.", QMessageBox.Ok)
            db.close()
        else:
            self.box = QMessageBox.information(self, 'Выполнено!', 'Учитель успешно добавлен!', QMessageBox.Ok)
            db.close()


class PupilRegForm(QWidget, UiPrf):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.initUI()

    def initUI(self):
        self.back_button.clicked.connect(self.back)
        self.reg_button.clicked.connect(self.add_pupil)
        db = sqlite3.connect(DATABASE_NAME)
        cur = db.cursor()
        res = cur.execute("""
        SELECT class_name FROM classes
            WHERE class_name !='admin'""").fetchall()
        for elem in res:
            self.class_cb.addItem(elem[0])
        db.close()

    def add_pupil(self):
        if self.name_line.text() == '' or self.surname_line.text() == '' or self.login_line.text() == '' \
                or self.pword_line.text() == '':
            self.box = QMessageBox.critical(self, "Ошибка", "Поля не должны быть пустыми.", QMessageBox.Ok)
        else:
            db = sqlite3.connect(DATABASE_NAME)
            cur = db.cursor()
            class_id = cur.execute(f"""
            SELECT id FROM classes
                WHERE class_name = '{self.class_cb.currentText()}'""").fetchone()[0]
            date = self.dateEdit.date().toString('dd.MM.yyyy')
            try:
                name = self.name_line.text()
                surname = self.surname_line.text()
                login = self.login_line.text()
                password = self.pword_line.text()
                cur.execute(f"""
                INSERT INTO users (name, surname, login, password, class_id, date_of_birth)
                    VALUES (
                    '{name}', '{surname}', '{login}', '{password}', {class_id}, '{date}'
                    )""")
                db.commit()
            except Exception:
                self.box = QMessageBox.critical(self, "Ошибка", "Данный логин уже занят.", QMessageBox.Ok)
            else:
                self.box = QMessageBox.information(self, 'Выполнено!', 'Ученик успешно добавлен!', QMessageBox.Ok)
            db.close()

    def back(self):
        self.sel_f = SelectionForm()
        self.sel_f.show()
        self.close()


class ClassAddForm(QWidget, UiCaf):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.initUI()

    def initUI(self):
        self.back_button.clicked.connect(self.back)
        self.add_button.clicked.connect(self.add_class)

    def add_class(self):
        db = sqlite3.connect(DATABASE_NAME)
        cur = db.cursor()
        if self.class_name.text() != '':
            try:
                cur.execute(f"""
                INSERT INTO classes ('class_name', 'shift')
                VALUES ('{self.class_name.text()}', {1 if self.first_shift.isChecked() else 2})""")
                db.commit()
                db.close()
            except Exception:
                self.box = QMessageBox.critical(self, "Ошибка", "Данный класс уже существует", QMessageBox.Ok)
            else:
                self.box = QMessageBox.information(self, 'Выполнено!', 'Класс успешно добавлен!', QMessageBox.Ok)
        else:
            self.box = QMessageBox.critical(self, "Ошибка", "Название класса не может быть пустым", QMessageBox.Ok)
        db.close()

    def back(self):
        self.sel_f = SelectionForm()
        self.sel_f.show()
        self.close()


class SelectionForm(QWidget, UiSf):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.initUI()

    def initUI(self):
        self.delete_marks_button.clicked.connect(self.delete_marks)
        self.back_button.clicked.connect(self.back)
        self.add_class.clicked.connect(self.class_add)
        self.add_pupil.clicked.connect(self.pupil_add)
        self.add_teacher.clicked.connect(self.teacher_add)
        self.remove_user.clicked.connect(self.user_remove)
        self.change_info.clicked.connect(self.info_change)
        self.change_class_name.clicked.connect(self.class_change)
        self.add_schedule.clicked.connect(self.schedule_add)
        self.change_rings.clicked.connect(self.rings_change)
        self.remove_class.clicked.connect(self.class_remove)

    def delete_marks(self):
        db = sqlite3.connect(DATABASE_NAME)
        cur = db.cursor()
        cur.execute("DELETE FROM marks")
        db.commit()
        db.close()
        self.box = QMessageBox.information(self, 'Выполнено', 'Переход успешно выполнен', QMessageBox.Ok)

    def schedule_add(self):
        self.s_a_f = ScheduleAddForm()
        self.s_a_f.show()
        self.close()

    def rings_change(self):
        self.r_c_f = RingChangeForm()
        self.r_c_f.show()
        self.close()

    def class_change(self):
        self.c_c_f = ClassChangeForm()
        self.c_c_f.show()
        self.close()

    def teacher_add(self):
        self.t_a_f = TeacherRegForm()
        self.t_a_f.show()
        self.close()

    def back(self):
        self.a_p = RegistrationForm()
        self.a_p.show()
        self.close()

    def class_add(self):
        self.c_a_f = ClassAddForm()
        self.c_a_f.show()
        self.close()

    def pupil_add(self):
        self.p_r_f = PupilRegForm()
        self.p_r_f.show()
        self.close()

    def class_remove(self):
        self.c_r_f = ClassRemoveForm()
        self.c_r_f.show()
        self.close()

    def info_change(self):
        self.u_c_f = UserChangeForm()
        self.u_c_f.show()
        self.close()

    def user_remove(self):
        self.u_r_f = UserRemoveForm()
        self.u_r_f.show()
        self.close()


class RegistrationForm(QWidget, UiRf):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.initUI()

    def initUI(self):
        self.login_button.clicked.connect(self.login)

    def login(self):
        if self.password_line.text() == '' or self.login_line.text() == '':
            self.box = QMessageBox.critical(self, 'Ошибка', 'Заполните все поля!', QMessageBox.Ok)
        else:
            db = sqlite3.connect(DATABASE_NAME)
            cur = db.cursor()
            res = cur.execute(f"""
            SELECT * FROM USERS
                WHERE login = '{self.login_line.text()}'
                AND password = '{self.password_line.text()}'""").fetchone()
            if res is None:
                self.box = QMessageBox.critical(self, "Ошибка", "Неверный логин или пароль", QMessageBox.Ok)
            else:
                if res[-3] == cur.execute("""
                SELECT id FROM classes
                WHERE class_name = 'admin'""").fetchone()[0]:
                    self.a_p = SelectionForm()
                    self.a_p.show()
                    self.close()
                elif res[-3] is not None:
                    name = res[1]
                    surname = res[2]
                    class_id = res[5]
                    student_id = res[0]
                    self.u_m_w = UserMainWindow(name, surname, class_id, student_id)
                    self.u_m_w.show()
                    self.close()
                else:
                    name = res[1]
                    surname = res[2]
                    subject_id = res[6]
                    date_of_birth = res[7]
                    self.t_m_w = TeacherMainWindow(name, surname, subject_id, date_of_birth)
                    self.t_m_w.show()
                    self.close()
            db.close()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = RegistrationForm()
    ex.show()
    sys.exit(app.exec_())
